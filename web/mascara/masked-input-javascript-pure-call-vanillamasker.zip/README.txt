A Pen created at CodePen.io. You can find this one at http://codepen.io/KingRider/pen/qNxror.

 Source Oficial:
https://github.com/BankFacil/vanilla-masker